<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppsCountry extends Model
{
    //
}

<?php $__env->startSection('adminContent'); ?>
<section class="content">
    <div class="row main-padding">
        <h3>Rooms</h3>
    </div>
    <div class="row main-padding">
        <div class="col-md-4"></div>
        <div class="col-md-2" style="padding-bottom:5px;">
                <button type="button"  onclick="AddnewRoom()" class="btn btn-warning">Add new</button>
        </div>
        <div class="col-md-2">
            <button type="button" onclick="DeleteAllRoom()" class="btn btn-danger">Delete all</button>
        </div>
        <div class="col-md-4"></div>
    </div>
    <div class="row">
        <div class="card-body">
            <div class="table-responsive">
            <table id="Rooms" class="table table-bordered table-hover">
              <thead>
              <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Price (Rs.)</th>
                <th>Quantity</th>
                <th>+ Bed price (Rs.)</th>
                <th>Actions</th>
              </tr>
              </thead>

              <tbody id="roomTable">
              <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('public/images/rooms')); ?>/<?php echo e($rooms->r_image); ?>" width="50px"></td>
                    <td><?php echo e($rooms->r_name); ?></td>
                    <td><?php echo e($rooms->r_price); ?></td>
                    <td><?php echo e($rooms->r_quantity); ?></td>
                    <td><?php echo e($rooms->r_additional_bed); ?></td>
                    <td>
                        <a onclick="DeleteSingleRoom(<?php echo e($rooms->r_id); ?>)" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash-alt"></i></a>
                        <a onclick="EditRoom(<?php echo e($rooms->r_id); ?>)"  class="btn btn-primary btn-sm" title="Edit"><i class="fas fa-pencil-alt"></i></a>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>

              <tfoot>
              <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>+ Bed price</th>
                <th>Actions</th>
              </tr>
              </tfoot>
            </table>
            </div>
          </div>
    </div>
</section>

<?php echo $__env->make('includes.roomModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>

    function AddnewRoom() {
        $('#exampleModalLongTitle').text('Add new room')
        $('#roomName').val('')
        $('#roomRate').val('')
        $('#roomQuantity').val('')
        $('#additionalBedRate').val('')
        $('.bd-newroom-modal-lg').modal('show')
    }
    
    $(document).ready( function () {
        $('#Rooms').DataTable( {
            responsive: true
        } );
    });

    $(document).ready(function (e) {
        $('#addNewRoom').on('submit',(function(e) {
        e.preventDefault()
        var NewRoom = new FormData(this)
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('add-new-room')); ?>",
            data: NewRoom,
            cache:false,
            contentType: false,
            processData: false,
            success: function (response) {
                $('.bd-newroom-modal-lg').modal('hide')
                $(".inputclear").val('');
                swal("Success!", "Added new room!", "success")
                $('#roomTable').empty()
                $.each(response.getRoom,function(k,v) { 
                    $('#roomTable').append('<tr><td><img src="<?php echo e(asset('public/images/rooms')); ?>/'
                    +v.r_image+'" width="50px"></td><td>'+v.r_name+'</td><td>'+v.r_price+'</td><td>'
                    +v.r_quantity+'</td><td>'+v.r_additional_bed+'</td><td><a onclick="DeleteSingleRoom('+v.r_id+')" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash-alt"></i></a><a href="<?php echo e(url('room-edit')); ?>/'
                    +v.r_id+'" class="btn btn-primary btn-sm" title="Edit"><i class="fas fa-pencil-alt"></i></a></td></tr>')
                })
            }
        })
    }))
    })

    function DeleteAllRoom() {
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('delete-all-rooms')); ?>",
                    data : {'_method' : 'GET'},
                    success: function (response) {
                    $('#roomTable').empty()
                    $.each(response.getRoom,function(k,v) { 
                    $('#roomTable').append('<tr><td><img src="<?php echo e(asset('public/images/rooms')); ?>/'
                    +v.r_image+'" width="50px"></td><td>'+v.r_name+'</td><td>'+v.r_price+'</td><td>'
                    +v.r_quantity+'</td><td>'+v.r_additional_bed+'</td><td><a onclick="DeleteSingleRoom('
                    +v.r_id+')" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash-alt"></i></a><a href="<?php echo e(url('room-edit')); ?>/'
                    +v.r_id+'" class="btn btn-primary btn-sm" title="Edit"><i class="fas fa-pencil-alt"></i></a></td></tr>')
                    })
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    })
            }
        })
        } else {
            swal("Your imaginary file is safe!");
        }
        })
    }

    function DeleteSingleRoom(id) {
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('room-delete')); ?>" + '/' + id,
                    data : {'_method' : 'GET'},
                    success: function (response) {
                        $('#roomTable').empty()
                        $.each(response.getRoom,function(k,v) { 
                            $('#roomTable').append('<tr><td><img src="<?php echo e(asset('public/images/rooms')); ?>/'
                            +v.r_image+'" width="50px"></td><td>'+v.r_name+'</td><td>'+v.r_price+'</td><td>'
                            +v.r_quantity+'</td><td>'+v.r_additional_bed+'</td><td><a onclick="DeleteSingleRoom('
                            +v.r_id+')" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash-alt"></i></a><a href="<?php echo e(url('room-edit')); ?>/'
                            +v.r_id+'" class="btn btn-primary btn-sm" title="Edit"><i class="fas fa-pencil-alt"></i></a></td></tr>')
                        })
                    }
                });
                swal("Poof! Your imaginary file has been deleted!", {
                icon: "success",
                });
            } else {
                swal("Your imaginary file is safe!");
            }
        });
    }

    function EditRoom(id) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('edit-room')); ?>"+ '/' + id,
            data : {'_method' : 'GET'},
            success: function (response) {
                $('#updateRoomId').val(response.r_id)
                $('#UpdateroomName').val(response.r_name)
                $('#UpdateroomRate').val(response.r_price)
                $('#UpdateroomQuantity').val(response.r_quantity)
                $('#UpdateadditionalBedRate').val(response.r_additional_bed)
                $('.bd-updateroom-modal-lg').modal('show')
            }
        });
    }

    function Updateroom() {
        $('#UpdateRoomForm').on('submit',(function(e) {
        e.preventDefault()
        var UpdateRoom = new FormData(this)
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('update-room')); ?>",
            data: UpdateRoom,
            cache:false,
            contentType: false,
            processData: false,
            success: function (response) {
                $('.bd-updateroom-modal-lg').modal('hide')
                $(".inputclear").val('');
                swal("Success!", "Updated room!", "success")
                $('#roomTable').empty()
                $.each(response.getRoom,function(k,v) { 
                    $('#roomTable').append('<tr><td><img src="<?php echo e(asset('public/images/rooms')); ?>/'
                    +v.r_image+'" width="50px"></td><td>'+v.r_name+'</td><td>'+v.r_price+'</td><td>'
                    +v.r_quantity+'</td><td>'+v.r_additional_bed+'</td><td><a onclick="DeleteSingleRoom('+v.r_id+')" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash-alt"></i></a><a href="<?php echo e(url('room-edit')); ?>/'
                    +v.r_id+'" class="btn btn-primary btn-sm" title="Edit"><i class="fas fa-pencil-alt"></i></a></td></tr>')
                })
            }
        })
    }))
    
     
    }
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/admin/rooms.blade.php ENDPATH**/ ?>
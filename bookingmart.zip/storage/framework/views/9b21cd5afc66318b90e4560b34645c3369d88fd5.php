<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
				<div id="gtco-logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/images/logo.jpeg')); ?>" width="20%"></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="#">Menu</a></li>
						<li><a href="#">Rooms</a></li>
						
						<li><a href="#">Contact</a></li>
					<li class="btn-cta"><a href="<?php echo e(url('reservation')); ?>"><span>Reservation</span></a></li>
					</ul>	
				</div>
			</div>
			
		</div>
    </nav>
    
    

    <?php echo $__env->yieldContent('content'); ?> 

	</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/layouts/app.blade.php ENDPATH**/ ?>
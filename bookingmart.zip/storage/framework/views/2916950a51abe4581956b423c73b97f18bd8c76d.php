<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservation</title>
</head>
<body>
<center>
    <img src="<?php echo e(asset('public/images/logo.jpeg')); ?>" width="50px">
    <h2>Under review your reservation!</h2>
</center>
<span>Hello, <?php echo e($name); ?></span><br>
<span>We received your reservation. We will confirm your reservation as soon as possible.</span>
</body>
</html><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/mails/BookingCustomerMail.blade.php ENDPATH**/ ?>
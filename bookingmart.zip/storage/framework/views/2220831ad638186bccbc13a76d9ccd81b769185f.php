<?php $__env->startSection('content'); ?>

<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background:url(public/images/cover_2.jpg)" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="gtco-container">
        <div class="row">
            <div class="col-md-12 col-md-offset-0 text-left">
                

                <div class="row row-mt-15em">
                    <div class="col-md-3"></div>
                    <div class="col-md-6 mt-text animate-box" data-animate-effect="fadeInUp">
                        <center>
                        <span class="intro-text-small">LUXURY SIGNATURE HOTEL IN SRI LANKA<a href="" target="_blank"></a></span>
                        <h1 class="cursive-font">Monaara!</h1>	<br>
                        <a href="<?php echo e(url('reservation')); ?>" class="btn btn-reserve btn-block">Reserve Now</a>
                        </center>
                    </div>
                    <div class="col-md-3"></div>
                    
                </div>
            </div>
        </div>
    </div>
</header>

<div class="gtco-section back01">
    <div class="gtco-container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                <h2 class="cursive-font primary-color">ACCOMMODATION</h2>
            </div>
        </div>
        <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-6">
                <a href="images/img_1.jpg" class="fh5co-card-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="<?php echo e(asset('public/images/rooms/1.jpg')); ?>" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Deluxe</h2>
                        <p>Traditional style & contentporary amenities for the discerning traveller..</p>
                        <p><span class="price cursive-font">Rs.2000.00</span></p>
                    </div>
                </a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <a href="images/img_2.jpg" class="fh5co-card-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="<?php echo e(asset('public/images/rooms/family_suits.jpg')); ?>" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Family Suits</h2>
                        <p>Traditional style & contentporary amenities for the discerning traveller..</p>
                        <p><span class="price cursive-font">Rs.5000.00</span></p>
                    </div>
                </a>
            </div>

        </div>
    </div>
</div>

<div id="gtco-features">
    <div class="gtco-container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
                <h2 class="cursive-font">Our Services</h2>
                <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="ti-face-smile"></i>
                    </span>
                    <h3>Happy People</h3>
                    <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="ti-thought"></i>
                    </span>
                    <h3>Creative Culinary</h3>
                    <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="ti-truck"></i>
                    </span>
                    <h3>Food Delivery</h3>
                    <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                </div>
            </div>
            

        </div>
    </div>
</div>










<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/welcome.blade.php ENDPATH**/ ?>
<?php echo $__env->make('includes.adminHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>

@media  print {
  .hidden-print {
    display: none !important;
  }
  @page  { size: auto;  margin: 0mm; }
}
.page {
    padding:50px;
    }
.i-box{
    color: #fff;
    font-weight: bold;
    
    background-color: #666666;
    padding: 10px;
    padding-top:17px;
}    
.thankYou{
    font-family: 'Pacifico', cursive;
    font-size: 70px;
}
.comeagain{
    font-family: 'Lexend Tera', sans-serif;
    font-size: 20px;
}
</style>
<link href="https://fonts.googleapis.com/css?family=Lexend+Tera|Pacifico&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
<br>
<?php
    date_default_timezone_set('Asia/Colombo');
?>
<center><button onclick="CreatePrint()" class="btn btn-danger hidden-print">Print</button></center>
    <div class="container" style="padding:30px;">
        <div class="row">
            <div class="col-4">
                <h1>INVOICE</h1>
            </div>
            <div class="col-4">
                <p>
                <center>
                   Issue Date : <?php echo e(date("F j, Y, g:i a")); ?>

                </center></p>
            </div>
            <div class="col-4">
                <img class="float-right" src="<?php echo e(asset('public/images/tempLogo.png')); ?>" width="50px" alt="">
            </div>
        </div>
        <hr>
        <div class="page">
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <p><b>Billed to:</b> <span id="CustomerId"></span> </P>
                <?php echo e($BillName); ?>,<br>
                <?php echo e($BillCustomerCountry); ?>,<br>
                <?php echo e($BillCustomerEmail); ?> <br>
                <?php echo e($BillCustomerContact); ?>

            </div>
            <div class="col-md-3 col-sm-3">
                <p><b>Arrival date:</b> <span id="CustomerId"></span> </P>
                <?php echo e($BillArrivalDate); ?>

            </div>
            <div class="col-md-3 col-sm-3">
                <p><b>Departure date:</b> <span id="CustomerId"></span> </P>
                <?php echo e($BillDepartureDate); ?>

            </div>
            <div class="col-md-3 col-sm-3">
                <p><b>Booking No:</b> <span id="CustomerId"></span> </P>
                <?php echo e($BillBookingId); ?>

            </div>
        </div>
        <br><br>
        <div class="row">
            <table width="100%" class="table table-bordered">
                <thead >
                    <tr>
                        <th style="width:70%">Description</th>
                        <th style="width:15%">Qty</th>
                        <th style="width:15%">Rate (Rs.)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr id="RoomDetails">
                        <td><?php echo e($BillRoomName); ?></td>
                        <td><?php echo e($BillRoomQty); ?></td>
                        <td><?php echo e(number_format($BillRoomRate,2)); ?></td>
                    </tr>
                    <?php if($BillPackageName != null): ?>
                        <tr id="PackageDetails">
                            <td><?php echo e($BillPackageName); ?></td>
                            <td>-</td>
                            <td><?php echo e(number_format($BillPackageRate,2)); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php if($BillBedRate != null): ?>
                    <tr id="AdditionalBedDetails">
                        <td>Additional Bed</td>
                        <td><?php echo e($BillBedQty); ?></td>
                        <td><?php echo e(number_format($BillBedRate,2)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php $__currentLoopData = $billDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="OrdersDetails">
                        <td><?php echo e($item->bill_pro_name); ?></td>
                        <td><?php echo e($item->bill_pro_qty); ?></td>
                        <td><?php echo e(number_format($item->bill_pro_price,2)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div><br><br>
        <div class="row">
            <div class="col-4"></div>
            <div class="col-3"></div>
            <div class="col-5">
                <div class="i-box float-right">
                    <p>Invoice  Total: <span style="font-size:25px">Rs.<?php echo e(number_format($OrdersGrandTotal,2)); ?><span></p>
                </div>
            </div>
        </div>
        <br><br>
        <div class="row" style="margin-top:100px">
            <div class="col-12">
                <center>
                    <span class="thankYou">
                        Thank You!
                    </span>
                    <br><br>
                    <span class="comeagain">
                        Come again
                    </span>
                </center>
            </div>
        </div>
       
    </div>
</div>   

<script>
    function CreatePrint() {
        window.print();
    }
    
</script>
<?php echo $__env->make('includes.adminFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/admin/print.blade.php ENDPATH**/ ?>
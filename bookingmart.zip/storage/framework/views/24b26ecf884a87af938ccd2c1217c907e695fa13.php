<?php $__env->startSection('adminContent'); ?>
<style>
.welcome{
    font-family: 'Pacifico', cursive;
    font-size: 70px;
}
</style>

<link href="https://fonts.googleapis.com/css?family=Lexend+Tera|Pacifico&display=swap" rel="stylesheet">

<div class="content">
    <h1 class="welcome">Welcome Back!</h1>
</div>    

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/admin/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservation</title>
</head>
<body>
<center>
    <img src="<?php echo e(asset('public/images/logo.jpeg')); ?>" width="50px">
    <h2>Congragulation!</h2>
    <span>You have a new reservation.Please check it and confirm it.</span><br>
    <span><a href="">Click here and check</a></span>
    
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/mails/BookingOwnerMail.blade.php ENDPATH**/ ?>
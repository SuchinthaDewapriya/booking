<?php $__env->startSection('adminContent'); ?>
<?php
    $mail = DB::table('settings')->first();
?>
<section class="content">
    <div class="row main-padding">
        <h3>Site Configuration</h3>
    </div>
    <div class="row main-padding">
        <form action="<?php echo e(url('notification-email')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="my-textarea">Notification Email</label>
            <input type="text" class="form-control" name="email" value="<?php echo e($mail->s_mail); ?>" placeholder="Email">
            <?php if($errors->has('email')): ?>
                <div class="alert alert-danger"><?php echo e($errors->first('email')); ?></div>
            <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-success">Save</button>
        </form>
    </div>
</section>        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookingmart\resources\views/admin/setting.blade.php ENDPATH**/ ?>